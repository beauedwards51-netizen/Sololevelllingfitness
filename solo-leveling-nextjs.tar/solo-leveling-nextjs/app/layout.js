import './globals.css'

export const metadata = {
  title: 'Solo Leveling Fitness',
  description: 'Level up in real life',
  themeColor: '#050510',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
